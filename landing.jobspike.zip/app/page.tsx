'use client'

import { useState } from 'react'

const features = [
  ['01', 'ATS-ready formatting', 'Make sure your resume gets parsed cleanly by the systems that decide what gets seen.'],
  ['02', 'Skills gap analysis', 'See the exact skills and signals missing from your target role.'],
  ['03', 'Bullet rewrites', 'Turn responsibilities into sharp, outcome-driven proof of your value.'],
  ['04', 'Job matching', 'Compare your resume against the roles you actually want, not generic advice.'],
]

export default function Page() {
  const [mobileOpen, setMobileOpen] = useState(false)

  return (
    <main className="min-h-screen overflow-hidden bg-background text-foreground">
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-6 py-6 lg:px-10" aria-label="Main navigation">
        <a href="#top" className="font-serif text-2xl font-semibold tracking-tight">Job<span className="text-accent">Spike</span></a>
        <div className="hidden items-center gap-8 text-sm text-muted-foreground md:flex">
          <a href="#how-it-works" className="transition-colors hover:text-foreground">How it works</a>
          <a href="#features" className="transition-colors hover:text-foreground">Features</a>
          <a href="#pricing" className="transition-colors hover:text-foreground">Pricing</a>
        </div>
        <div className="hidden items-center gap-4 md:flex">
          <button className="text-sm font-medium text-muted-foreground hover:text-foreground">Sign in</button>
          <a href="#score" className="rounded-xl bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground shadow-soft transition-transform hover:-translate-y-0.5">Get your score</a>
        </div>
        <button onClick={() => setMobileOpen(!mobileOpen)} className="rounded-lg border border-border p-2 md:hidden" aria-expanded={mobileOpen} aria-label="Toggle menu"><span className="block h-0.5 w-5 bg-foreground" /><span className="mt-1.5 block h-0.5 w-5 bg-foreground" /></button>
      </nav>
      {mobileOpen && <div className="mx-6 flex flex-col gap-4 border-t border-border py-5 text-sm md:hidden"><a href="#how-it-works">How it works</a><a href="#features">Features</a><a href="#pricing">Pricing</a></div>}

      <section id="top" className="mx-auto grid max-w-7xl gap-14 px-6 pb-24 pt-14 lg:grid-cols-[1.05fr_.95fr] lg:items-center lg:px-10 lg:pb-32 lg:pt-24">
        <div>
          <p className="mb-7 font-mono text-xs font-medium uppercase tracking-[0.2em] text-accent">Your unfair advantage</p>
          <h1 className="max-w-3xl font-serif text-5xl leading-[1.02] tracking-[-0.04em] text-balance sm:text-6xl lg:text-8xl">The resume that gets you <em className="text-accent">unstuck.</em></h1>
          <p className="mt-8 max-w-xl text-lg leading-8 text-muted-foreground">Stop guessing why you&apos;re getting passed over. JobSpike shows you exactly what your resume is saying, what it&apos;s missing, and how to fix it.</p>
          <div className="mt-10 flex flex-wrap items-center gap-5 text-sm text-muted-foreground"><span className="flex items-center gap-2"><span className="h-2 w-2 rounded-full bg-accent" />Free instant score</span><span>No credit card</span></div>
        </div>
        <div id="score" className="rounded-xl border border-border bg-card p-3 shadow-soft">
          <div className="rounded-lg border border-dashed border-accent/50 bg-secondary/40 p-8 text-center sm:p-12">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-accent text-2xl font-semibold text-accent-foreground">↑</div>
            <h2 className="mt-6 font-serif text-2xl">Drop your resume here</h2>
            <p className="mt-2 text-sm text-muted-foreground">PDF or DOCX · We&apos;ll keep it private</p>
            <button type="button" className="mt-7 rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-transform hover:-translate-y-0.5">Choose your resume</button>
            <p className="mt-4 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Visual preview · upload coming soon</p>
          </div>
          <div className="flex items-center justify-between px-3 pb-1 pt-5"><div><p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Sample resume score</p><p className="mt-1 text-sm font-medium">Product Designer · 4 signals found</p></div><span className="font-serif text-4xl text-accent">78</span></div>
        </div>
      </section>

      <section id="how-it-works" className="border-y border-border bg-secondary/45"><div className="mx-auto max-w-7xl px-6 py-20 lg:px-10"><div className="mb-14 flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><p className="font-mono text-xs uppercase tracking-[0.2em] text-accent">A clearer path forward</p><h2 className="max-w-lg font-serif text-4xl leading-tight tracking-tight sm:text-5xl">From overlooked to <em>obvious.</em></h2></div><div className="grid gap-10 md:grid-cols-3">{[['01','Scan','Get an honest read on how your resume performs.'],['02','See the gaps','Understand what recruiters and ATS systems are looking for.'],['03','Make your move','Use specific, useful edits to put your best work forward.']].map(([number,title,copy]) => <div key={number} className="border-t border-foreground/20 pt-5"><span className="font-mono text-xs text-accent">{number}</span><h3 className="mt-12 font-serif text-2xl">{title}</h3><p className="mt-3 max-w-xs leading-7 text-muted-foreground">{copy}</p></div>)}</div></div></section>

      <section id="features" className="mx-auto max-w-7xl px-6 py-24 lg:px-10 lg:py-32"><div className="grid gap-14 lg:grid-cols-[.8fr_1.2fr]"><div><p className="font-mono text-xs uppercase tracking-[0.2em] text-accent">Built for the job hunt</p><h2 className="mt-6 max-w-md font-serif text-4xl leading-tight tracking-tight sm:text-5xl">Less advice.<br /><em>More signal.</em></h2></div><div className="grid gap-x-8 gap-y-12 sm:grid-cols-2">{features.map(([number,title,copy]) => <article key={number} className="border-t border-border pt-4"><span className="font-mono text-xs text-muted-foreground">{number}</span><h3 className="mt-8 font-serif text-2xl">{title}</h3><p className="mt-3 leading-7 text-muted-foreground">{copy}</p></article>)}</div></div></section>

      <section id="pricing" className="bg-primary text-primary-foreground"><div className="mx-auto flex max-w-7xl flex-col justify-between gap-10 px-6 py-20 lg:flex-row lg:items-end lg:px-10 lg:py-24"><div><p className="font-mono text-xs uppercase tracking-[0.2em] text-accent">Start free</p><h2 className="mt-5 max-w-2xl font-serif text-4xl leading-tight tracking-tight sm:text-6xl">Your next opportunity<br /><em>starts with a score.</em></h2></div><a href="#score" className="w-fit rounded-xl bg-accent px-6 py-4 text-sm font-semibold text-accent-foreground transition-transform hover:-translate-y-0.5">Score my resume <span aria-hidden="true">↗</span></a></div></section>

      <footer className="mx-auto flex max-w-7xl flex-col gap-4 px-6 py-8 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between lg:px-10"><p className="font-serif text-lg text-foreground">Job<span className="text-accent">Spike</span></p><p>© 2026 JobSpike. Make your move.</p><div className="flex gap-5"><a href="#top" className="hover:text-foreground">Privacy</a><a href="#top" className="hover:text-foreground">Terms</a></div></footer>
    </main>
  )
}
